﻿using System;

namespace BeforeDawn
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Source cited from:");
            Console.WriteLine(" Mazegame: https://www.youtube.com/watch?v=T0MpWTbwseg");
            Console.WriteLine("In class material: explorable map");
            Console.WriteLine("Monster Combat: I set multiple times of tutorial appoitments with Austin Derrickson to figure out this section about how to realize doing the combat by provding multiple choices for player to choose their moveset.");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("This is a forest called <Before Dawn>. There is only night in the forest, you are going to get rid of the forest to looking for a day come.");
            Game game = new Game();
            Console.Title = "Before Dawn";
            Console.CursorVisible = false;
          


        }
    }
}
