﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
namespace BeforeDawn
{
    class Game
    {
        //public List<Item> Itemlist;
        public List<Room> room;
        public Player player1=new Player(1,1) {Name="" };
        public bool pickupitem = true;
        

       public Game()
        {
            Setup();
        }
     
        public void Setup()
        {
            room = new List<Room>();
            player1 = new Player(1, 1)
            {
                Name = "",
                iteminbag = new List<Item>(),
                grades=0
            };
            Item Map = new Item("Map");
          
            Room Village = new Room
            {
                Name = "Village",
                Iteminroom = new List<Item>() { Map },
                RequiredItem = null

            };
            room.Add(Village);


            Item Key2 = new Item("Key for cave");
            Room Lake = new Room
            {
                Name = "Lake",
                
                Iteminroom = new List<Item>() { Key2 },
                RequiredItem = new List<Item>() { Map }

            };
            room.Add(Lake);
            Item Map2 = new Item("Treausre Map");
            Monster Tyrannosaurus_rex = new Monster()
            {
                Name = "Kelly",
                Blood = 1000,
                monstermove = new List<Move>()
                //move = new List<Move>() { light_wave, bite, Hitting }

            };
            Room Cave = new Room
            {
                Name = "Arcane Cave",
                Iteminroom = new List<Item>() { Map2 },
                RequiredItem = new List<Item>() { Key2 },
                NPC=Tyrannosaurus_rex,
                //NPC=MonsterCombat.Trrannosaurus_rex
              
        };
            room.Add(Cave);

            Item Treasure = new Item("Treasure");
            Room Treasureroom = new Room
            {
                Name = "Treasure",
                Iteminroom = new List<Item>() { Treasure },
                RequiredItem = new List<Item>() { Map2 },
               


            };

          
                
                
            Greeting();

        }

        public void Greeting()
        {
            Console.WriteLine("Hello，what is your name");
            string inputname = Console.ReadLine();
            if(inputname!=null)
            {
                player1.Name = inputname;
                Console.WriteLine($"{player1.Name}, you are in the forest");
                Console.WriteLine("Press any key to continue...");
                Console.ReadKey();
                showmenu();
            }
           else
            {
                Console.WriteLine("Please write a name");
                Greeting();
            }
        }

        public void showmenu()
        {
            Console.Clear();
            Console.WriteLine("Menu:");
            Console.WriteLine("Forest Menu");
            Console.WriteLine("1) view forest");
            Console.WriteLine("2) Check your bag");
            Console.WriteLine("3)Exit");

            var userInput = Console.ReadKey();
           Console.Clear();

            if (userInput.Key == ConsoleKey.D1 || userInput.Key == ConsoleKey.NumPad1)
            {
                showmap();
              
            }
            else if (userInput.Key == ConsoleKey.D2 || userInput.Key == ConsoleKey.NumPad2)
            {

                Console.WriteLine("Viewing bag");
              
               
            }
          
            else if(userInput.Key==ConsoleKey.D3||userInput.Key==ConsoleKey.NumPad3)
            {
                Console.WriteLine("See you");
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Please input a valid number");
                showmenu();

            }
           

        }

        
        public void showmap()
        {
            Console.WriteLine("Viewing rooms");
          // Console.Clear();
            int index = 1;

            foreach (Room room in room)
            {
                Console.WriteLine($"{index}{room.Name}");
                index++;
            }
            Console.WriteLine($"{index} Exit");
            Console.WriteLine("Where do you want to go?");


            int inputasnumber = Utility.GetNumberFromUser(index);
            if (inputasnumber == index)
            {
                Console.WriteLine("Good Bye");
                Environment.Exit(0);
            }

            Room selectedroom = room[inputasnumber - 1];
            bool canusermovetothisroom = movetoroom(selectedroom);


            if (canusermovetothisroom)
            {
                showroom(selectedroom);
            }
            else
            {
               
                showmap();
            }

            
        }
        public bool movetoroom(Room room)
        {
            bool canusermovetoroom = true;
            if (room.RequiredItem != null)
            {
                foreach (Item i in room.RequiredItem)
                {
                    if (!player1.iteminbag.Contains(i))
                    {
                        Console.WriteLine($"You are missing {i.Name} ");
                        canusermovetoroom = false;
                    }
                }
            }
            return canusermovetoroom;

        }

      public void showroom(Room room)
        {

            Console.Clear();
            int Index = 1;
         
           
                Console.WriteLine($"The room has:");
                foreach (Item item in room.Iteminroom)
                {
                    Console.WriteLine($"{Index}.{item.Name}");
                    Index++;

                }
                Console.WriteLine($"{Index} Exit room.");
                Console.WriteLine("What do you want to pick?");
                int inputasnumber = Utility.GetNumberFromUser(Index);
            if (inputasnumber == Index)
            {
                showmap();
            }
            Item itemselected = room.Iteminroom[inputasnumber - 1];
            bool Pickingupitem = Pickupitem(room, itemselected);
            if (Pickingupitem)
            {
                if (room.Name == "Village")
                {
                    room.roomrequirement = room.villagerequirement();
                    gameinvillage(room);

                }
                if(room.Name=="Lake")
                {
                    GameInLake(room);

                }
                if (room.Name == "Arcane Cave")

                {

                    gameinroom();
                    
                        Environment.Exit(0);
                   Console.WriteLine("Congratulation, you get rid of the forest and a brand new day start.");
                    Console.WriteLine("Source cited from:");
                    Console.WriteLine(" Mazegame: https://www.youtube.com/watch?v=T0MpWTbwseg");
                    Console.WriteLine("In class material: explorable map");
                    Console.WriteLine("Monster Combat: I set multiple times of tutorial appoitments with Austin Derrickson to figure out this section about how to realize doing the combat by provding multiple choices for player to choose their moveset.");
                   
                  
                }
                Console.WriteLine($"Now you have {itemselected.Name} in bag");
            }
           else
            {
                Console.WriteLine("You already have the stuff, you can go to the next room");
            }
            player1.iteminbag.Add(itemselected);
            //Console.WriteLine($"Now you have {itemselected.Name} in bag");
            showroom(room);



        }

        public void gameinroom(/*Room r, Game g*/)
        {
            /* r.GameinRooms = new List<Game>();
             NpcinRooms = new List<character>();*/
            Console.Clear();
            Console.WriteLine("You meet a Tyrannosaurus_rex in the Arcane Cave, her name is Kelly. This is your last stage, you need to beat her down so that you can escape from the forest. ");
            Monster Tyrannosaurus_rex = new Monster()
            {
                Name = "Kelly",
                Blood = 1000,
                monstermove = new List<Move>()
            };
            //NpcinRooms.Add(Tyrannosaurus_rex);
            MonsterCombat combat = new MonsterCombat(player1);
           

            /*foreach(Room rooms in room)
            {
                foreach(Game games in r.GameinRooms)
                {
                    MonsterCombat combat = new MonsterCombat();
                }
            }*/
        }

        public void gameinvillage(Room room)

        {
            Console.Clear();
            Console.WriteLine($"You are in the {room.Name} stage");
            Console.WriteLine("Before go to the forest, you need to answer following questions to make sure your safety.");
            Console.WriteLine($"You are in the {room.Name} stage");

            guidebook guide = new guidebook(player1);
           

        }

        public void GameInLake(Room room)
        {
            Console.Clear();
           
            MazeGame MAZE = new MazeGame(player1);
        }
     public bool Pickupitem(Room room,Item item1)
        {
            List<Item> Iteminroom = new List<Item>();
            room.Iteminroom = Iteminroom;
            foreach (Item item in room.Iteminroom)
            {
                if (player1.itemname.Contains(item.Name))
                {
                    pickupitem = false;
                }

            }
            return pickupitem;
        }

      



    }
}
