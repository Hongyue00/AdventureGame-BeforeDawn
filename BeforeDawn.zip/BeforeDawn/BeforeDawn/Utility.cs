﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace BeforeDawn
{
    class Utility
    {
        public static int GetNumberFromUser(int numberofitems)
        {
           
            Console.WriteLine($"Enter a number between 1 and {numberofitems}");
            string input = Console.ReadLine();
            int inputasnumber = -1;
            if (int.TryParse(input, out inputasnumber) && inputasnumber > 0 && inputasnumber <= numberofitems)
            {
                return inputasnumber;
            }
            else
            {
                Console.WriteLine("Invalid");
                return GetNumberFromUser(numberofitems);
            }
        }
    }
}
