﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class Mazeworld
    {
        public string[,] maze;
        public int row;
        public int cols;

        public Mazeworld(string[,] Maze)
        {
            maze = Maze;
            row = Maze.GetLength(0);
            cols = Maze.GetLength(1);
        }

        public void Draw()
        {
            for (int y = 0; y < row; y++)
            {
                for (int x = 0; x < cols; x++)
                {
                    string element = maze[y, x];
                    Console.SetCursorPosition(x, y);
                    Console.Write(element);
                }

            }
        }

        public void SetMazeString(int x, int y, string s)
        {
            this.maze[y, x] = s;
        }

        public string GetElementAt(int x, int y)
        {
            return maze[y, x];
        }

        public bool canusermovetotheposition(int x, int y)
        {
            if (x < 0 || y < 0 || x >= row || y >= row)
            {
                return false;
            }
            return maze[y, x] == "    " || maze[y, x] == "X";
        }

    }
}

