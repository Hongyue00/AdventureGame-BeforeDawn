﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class MazeGame
    {
        public Mazeworld mazeworld;
        public Player Player1;

        public MazeGame(Player player)
        {
            Player1 = player;
            start();
        }
        public void start()
        {
            
            string[,] maze =
          {
              
                {"=","====","====","====","====","====","====","====","=" },
                {"=","   O","====","    ","    ","    ","    ","    ","=" },
                {"=","    ","====","    ","    ","    ","    ","    ","=" },
                {"=","    ","====","    ","    ","    ","    ","    ","=" },
                {"=","    ","====","====","====","====","====","====","=" },
                {"=","    ","    ","    ","    ","    ","    ","    ","X" },
                {"=","    ","====","====","====","====","====","====","=" },
                {"=","    ","====","    ","    ","    ","    ","    ","=" },
                {"=","====","====","====","====","====","====","====","=" }
              
            };
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("You are in the lake stage");
            Console.WriteLine("  There is a maze in the lake, you need to exit from the maze and then get to the next stage.");
            Console.WriteLine("  Maze game is starting, the maze start with the O, you will win the game when reach the X.");
            mazeworld = new Mazeworld(maze);

            Player1 = new Player(1, 1);
            Rungame();

        }


        private void Drawframe()
        {
            //comment: The error is caused by the while loop, you just need draw it once.
            //Console.Clear();
            mazeworld.Draw();
            Player1.Draw();
        }

        private void Handleplayerinput()
        {
            ConsoleKeyInfo keyInfo = Console.ReadKey(true);
            ConsoleKey Key = keyInfo.Key;
            switch (Key)
            {

                case ConsoleKey.UpArrow:
                    if (mazeworld.canusermovetotheposition(Player1.X, Player1.Y - 1))
                    { Player1.Y -= 1; }
                    
                    break;
                case ConsoleKey.DownArrow:
                    if (mazeworld.canusermovetotheposition(Player1.X, Player1.Y + 1))
                    { Player1.Y += 1; }
                    
                    break;
                case ConsoleKey.LeftArrow:
                    if (mazeworld.canusermovetotheposition(Player1.X - 1, Player1.Y))
                    { Player1.X -= 1; }
                    
                    break;
                case ConsoleKey.RightArrow:
                    if (mazeworld.canusermovetotheposition(Player1.X + 1, Player1.Y))
                    { Player1.X += 1; }
                    
                    break;
                default:
                    break;


            }
        }
        private void Rungame()
        {
            while (true)
            {
                Drawframe();
                int preX = Player1.X;
                int preY = Player1.Y;
                //System.Threading.Thread.Sleep(20);
                Handleplayerinput();

               

                if (mazeworld.canusermovetotheposition(Player1.X, Player1.Y) == false)
                    continue;

                string elementAtPlayerPosition = mazeworld.GetElementAt(Player1.X, Player1.Y);
                if (String.Equals(elementAtPlayerPosition, "X"))
                {
                    Console.Clear();
                    Console.WriteLine("Congratulations! You Win!");
                    break;
                }
                else
                {
                    mazeworld.SetMazeString(preX, preY, "    ");
                    mazeworld.SetMazeString(Player1.X, Player1.Y, " O  ");
                }
                mazeworld.Draw();
                System.Threading.Thread.Sleep(20);
            }
        }


    }

}

