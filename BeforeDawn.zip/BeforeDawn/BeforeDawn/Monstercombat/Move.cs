﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class Move
    {
        public string MoveName;
        public int Hurt;

        public Move()
        {

        }
    }
}
