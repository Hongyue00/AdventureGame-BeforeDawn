﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class MonsterCombat
    {
        public List<Monster> monster;
        public Player player1;

        Monster Tyrannosaurus_rex = new Monster()
        {
            Name = "Kelly",
            Blood = 1000,


        };




        public MonsterCombat(Player player)
        {
            player1 = player;
            Combat_start();
        }
        public void Combat_start()
        {
           
           
            Console.WriteLine("Combat start");
            character currentcharacter = new character();
            character opponent = new character();
            currentcharacter = player1;
            opponent = Tyrannosaurus_rex;
            while (opponent.alive)
            {
                // currentcharacter.Combat();
                Console.WriteLine($"{currentcharacter.Name} is going to have a combat with {opponent.Name}");
               
                int input = 0;
                if (currentcharacter.GetType() == player1.GetType())
                {
                    /*foreach (Move move in currentcharacter.MoveSet)
                    {
                        Console.WriteLine(move.MoveName);
                    }*/

                    for (int i = 0; i < currentcharacter.MoveSet.Count; i++)
                    {
                        Console.WriteLine($"{i + 1} : {currentcharacter.MoveSet[i].MoveName}");
                    }
                    input = int.Parse(Console.ReadLine()) - 1;
                }

                else
                {
                    Random rand = new Random();
                    input = rand.Next(0, 2);
                }
               
               int opponentdamage = currentcharacter.Combat(currentcharacter.MoveSet[input].Hurt);
                Console.WriteLine($"{currentcharacter.Name} has {currentcharacter.Blood}");
                Console.WriteLine(currentcharacter.MoveSet[input].MoveName,currentcharacter.MoveSet[input].Hurt);
                //Console.WriteLine($"{opponent.Name} has {opponent.Blood}");
                opponent.takingdamage(opponentdamage);
                if (opponent.Blood <= 0)
                {
                    opponent.alive = false;
                    Console.WriteLine("Congratulation, you get rid of the forest and a brand new day start.");
                }
                else
                {
                    character temp = new character();
                    temp = currentcharacter;
                    currentcharacter = opponent;
                    opponent = temp;

                }
                Console.Clear();
                Console.WriteLine($"{opponent.Name} is attacking {currentcharacter.Name}");
                Console.WriteLine($"{currentcharacter.Name} still has Blood {currentcharacter.Blood}");
           
                Console.WriteLine($"{opponent.Name} still has Blood {opponent.Blood}");
               
                Console.ReadKey();
                //while (Ifcombatcontinue())
                //{
                //  // player1.PlayerCombat();


                //}

                // Fight(Tyrannosaurus_rex);




                //Console.WriteLine(player1.Blood);
                //Console.WriteLine(Tyrannosaurus_rex.Blood);
            }
        }


        
    }
}

