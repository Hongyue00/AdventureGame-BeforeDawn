﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class Monster : character
    {
       
        public List<Move> monstermove;
        public Monster()
        {
            MonsterCombat();
        }
        public void MonsterCombat()
        {
            /*monstermove = new List<Move>();*/
            Move light_wave = new Move()
            {
                MoveName = "Light_wave",
                Hurt = 300

            };
            Move bite = new Move()
            {
                MoveName = "biting",
                Hurt = 50
            };

            Move Hitting = new Move()
            {
                MoveName = "hitting",
                Hurt = 100
            };

            MoveSet.Add(light_wave);
            MoveSet.Add(bite);
            MoveSet.Add(Hitting);

        }
        /*public void takingdamage(Move move)
        {
            Blood = Blood - move.Hurt;
        }*/
    }
}
