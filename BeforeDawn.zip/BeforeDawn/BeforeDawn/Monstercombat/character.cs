﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class character
    {
        public string Name;
        public bool alive = true;
        public int Blood=1000;
        public List<Move> MoveSet = new List<Move>();
        public List<Move> move;

        public int Combat(int damage)
        {
            return damage;
        }
        public void takingdamage(Move move)
        {
            Blood = Blood - move.Hurt;
        }
        public void takingdamage(int damage)
        {
            Blood = Blood - damage;
        }
    }
}
