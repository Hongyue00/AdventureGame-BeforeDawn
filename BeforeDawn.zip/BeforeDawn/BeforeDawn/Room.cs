﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace BeforeDawn
{
    class Room
    {
        public string Name;
        public List<Item> Iteminroom;
        public List<Item> RequiredItem;
        public character NPC;
        public List<Game> GameinRooms;
        public bool roomrequirement;
        public Player player1 = new Player(1, 1);
       
        public bool villagerequirement()
        {
            bool villageRequirement = false;
            if (player1.grades >= 4)
            {
                villageRequirement = true;
            }
            return villageRequirement;
        }



    }
}
