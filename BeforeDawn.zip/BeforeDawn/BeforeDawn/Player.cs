﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace BeforeDawn
{
    class Player : character
    {
        //public string Name;
        public List<Item> iteminbag;
        public List<string> itemname;
        public int PlayerBlood;
        public int grades=0;
        public int X;
        public int Y;
        public string PlayerMaker;
        public ConsoleColor Playercolor;

        /*public List<Move> player_move { get; set; } = new List<Move>();*/

        public Player(int initialX,int initialY)
        {
            X = initialX;
            Y = initialY;
            PlayerMaker = "O";
            Playercolor = ConsoleColor.Blue;
             PlayerCombat();
        }
      
        public void pickupiteminbag(Item item,Room room)
        {

            if (!iteminbag.Contains(item)&&room.roomrequirement==true)
            {
                Console.WriteLine("You can pick it up");
                iteminbag.Add(item);
            }
            
            else
            {
                Console.WriteLine($"You already have the {item.Name} in bag ");
               
            }

            Console.Clear();
            showiteminbag();
          

        }

        public void showiteminbag()
        {
            itemname = new List<string>();

            foreach (Item G in iteminbag)
            {

                itemname.Add(G.Name);
            }
            Console.WriteLine($"You have these item(s): {String.Join(",", itemname)}");


        }

        public void Draw()
        {
            Console.ForegroundColor = Playercolor;
            Console.SetCursorPosition(X, Y);
            Console.Write(PlayerMaker);
            Console.ResetColor();

        }

        public void PlayerCombat()
        {


            Move stab = new Move()
            {
                MoveName = "stabbing",
                Hurt = 200
            };

            MoveSet.Add(stab);
            Move SLAP = new Move()
            {
                MoveName = "Slaping",
                Hurt = 100
            };

            MoveSet.Add(SLAP);
            Move scratch = new Move()
            {
                MoveName = "scratching",
                Hurt = 50
            };
            MoveSet.Add(scratch);
            /*Random rand = new Random();
            player_move = new List<Move> { stab, SLAP, scratch };
            //Random random = new Random();
            //string r = random.Next(0, player_move.Count);
            foreach (Move moves in player_move)
            {
                int index = 1;
                Console.WriteLine($"{index}{moves.MoveName}");
                index++;

            }*/
        }
        /*public void takingdamage(Move move)
        {
            Blood = Blood - move.Hurt;
        }*/
    }
}