﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;

namespace BeforeDawn
{
    class Item
    {

        public string Name;
        public string Discription;
        public bool User_can_pick;

        public Item(string name)
        {
            Name = name;
        }
    }
}
