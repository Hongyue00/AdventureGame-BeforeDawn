﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class guidebook
    {
        public List<exercise> Quiz;
        public exercise Exercise;
        Player player1;
        Game game;
       
        public List<int> tracking = new List<int>();
        System.Random rand = new System.Random();
        
        //public Player player1;
        

        
        public guidebook(Player player)
        {
            player1 = player;
            
            showquestions();
        }
        public void showquestions()
        {

            exercise exercise1 = new exercise("1.", "When lost in the wilderness, what's the first thing you should do?", "A Yell for help B Find Water C Make a shelter D Sit for a minue and collect your thought", "D");
            exercise exercise2 = new exercise("2.", "What is the biggest priority when lost outdoors?", "A Shelter B Food C Water D Bathroom", "A");
            exercise exercise3 = new exercise("3.", "What's the best survival tip to remember?", "A Remain calm and don't panic B Always carrying a folding knife C Collect bird egg for survival food D Use a mirror to signal for help", "A");
            exercise exercise4 = new exercise("4.", "What's the BEST way to make sure your drinking water is safe?", "A. Leave it out in sunlight so UV rays can kill organism B.Filter it through shirt or handkerchief C.Add green grass and leaves and let plant materials kill the microbes D.Boil it", "D");
            exercise exercise5 = new exercise("6.", "If you walk towards the sun, what direction would you be walking", "A North B South C.East D West", "B");
            exercise exercise6 = new exercise("7.", "What's the most reliable way to navigate in the wilderness at NIGHT?", "A Animal trails B The moss on the north side of trees C The moon D The stars", "D");

            Quiz = new List<exercise>();
            Quiz.Add(exercise1);
            Quiz.Add(exercise2);
            Quiz.Add(exercise3);
            Quiz.Add(exercise4);
            Quiz.Add(exercise5);
            Quiz.Add(exercise6);
            int Index = 0;
            if (Index <= Quiz.Count)
            {
                for (int i = 0; i < Quiz.Count; i++)
                {
                    Console.WriteLine(Quiz[Index].Questions);
                    Console.WriteLine(Quiz[Index].Answer);
                    exercise e = Quiz[Index];
                    CheckAnswer(e);
                    Index++;
                   

                }
                Console.Clear();

            }


        }
            public void CheckAnswer(exercise e)
            {
                Console.WriteLine("What is the answer?");
                string input = Console.ReadLine();
                input = input.ToUpper();
                if (input == e.CorrectAnswer)
                {
                    Console.WriteLine("That is correct");
                    player1.grades++;
                }
                else
                {
                    Console.WriteLine("That is wrong");

                }
                Console.WriteLine($"Your score is {player1.grades}");
                Console.ReadKey();
            }


        }
        
    }
