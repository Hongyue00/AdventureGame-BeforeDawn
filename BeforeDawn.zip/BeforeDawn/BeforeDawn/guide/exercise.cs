﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BeforeDawn
{
    class exercise
    {
        public string NameofDefinition;
        public string Questions;
        public string Answer;
       // public List<string> Answer;
        public string CorrectAnswer;
        public exercise(string name, string questions, string answer, string correctanswer)
        {
            NameofDefinition = name;
            Questions = questions;
            CorrectAnswer = correctanswer;
            Answer = answer;
          // Answer = new List<string>();

            //Answer.AddRange(answer);
        }
    }
}
